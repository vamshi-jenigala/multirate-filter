`timescale 1ns / 1ps
// Company: apex technologies
// Engineer: vamshi jenigala 
// Create Date: 09.05.2026 17:48:08 
// Module Name: tb_top

module tb_top;
reg clk;
reg signed [15:0] din;
reg din_valid;
wire signed [15:0] dec_out;
wire dec_valid;
wire signed [15:0] dout0, dout1, dout2, dout3;
wire dout_valid;
reg [15:0] input_mem [0:4095];
integer i, file_dec, file_int;
initial clk = 0;
always #4.167 clk = ~clk;
top uut (
        .clk(clk),
        .din(din),
        .din_valid(din_valid),
        .dec_out(dec_out),
        .dec_valid(dec_valid),
        .dout0(dout0),
        .dout1(dout1),
        .dout2(dout2),
        .dout3(dout3),
        .dout_valid(dout_valid)
    );
initial begin
$readmemh("input_hex.txt", input_mem);
file_dec = $fopen("decimator_output.txt", "w");
file_int = $fopen("interpolator_output.txt", "w");
din=0;
din_valid=0;
#100;
for (i = 0; i < 4096; i = i + 1) begin
            @(posedge clk);
            din <= input_mem[i];
            din_valid <= 1'b1;
end
@(posedge clk);
din_valid <= 1'b0;
#50000;
$fclose(file_dec);
$fclose(file_int);
$display("Simulation Finished. Files saved.");
$stop;
end
always @(posedge clk) begin
        if (dec_valid) begin
            $fwrite(file_dec, "%d\n", dec_out);
        end
end
always @(posedge clk) begin
        if (dout_valid) begin
            $fwrite(file_int, "%d\n", dout0);
            $fwrite(file_int, "%d\n", dout1);
            $fwrite(file_int, "%d\n", dout2);
            $fwrite(file_int, "%d\n", dout3);
        end
end
endmodule
