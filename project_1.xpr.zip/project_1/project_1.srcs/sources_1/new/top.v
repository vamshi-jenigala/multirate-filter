module top(
    input clk,
    input signed [15:0] din,      
    input din_valid,
    output signed [15:0] dec_out, 
    output dec_valid,
    output signed [15:0] dout0, dout1, dout2, dout3,
    output dout_valid
);
wire [31:0] m_axis_dec_tdata;
wire [131:0] m_axis_int_tdata;
assign dec_out = m_axis_dec_tdata[15:0];
fir_decimator decimator_inst (
        .aclk(clk),
        .s_axis_data_tvalid(din_valid),
        .s_axis_data_tdata(din),
        .m_axis_data_tvalid(dec_valid),
        .m_axis_data_tdata(m_axis_dec_tdata)
    );
fir_interpolator interpolator_inst (
        .aclk(clk),
        .s_axis_data_tvalid(dec_valid),
        .s_axis_data_tdata(dec_out),
        .m_axis_data_tvalid(dout_valid),
        .m_axis_data_tdata(m_axis_int_tdata)
    );
assign dout0 = m_axis_int_tdata[15:0];
assign dout1 = m_axis_int_tdata[48:33];
assign dout2 = m_axis_int_tdata[81:66];
assign dout3 = m_axis_int_tdata[114:99];
endmodule    
    
